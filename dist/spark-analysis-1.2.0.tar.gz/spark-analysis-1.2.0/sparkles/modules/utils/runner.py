from sqlalchemy import text
from models import Base, config_to_db_session, fs_to_ds, Dataset, Analysis
from datetime import datetime
import getpass
import re
from subprocess import call
import yaml
import os
from os.path import dirname
import shutil
import errno
from swiftclient.service import *


class SparkRunner(object):

    def __init__(self, configpath=None):

        config = None
        if(configpath is None):
            configpath = '/shared_data/etc/config.yml'
        with open(configpath, 'r') as config_file:
            config = yaml.load(config_file)

        print(config)
        self.session = config_to_db_session(config, Base)
        self.config = config

    def list_analysises(self):

        print('List of available modules')
        analysismodules = self.session.query(Analysis).all()
        for am in analysismodules:
            print(am.name)

    def list_datasets(self):
        print('List of available datasets')
        datasets = self.session.query(Dataset).all()
        for dataset in datasets:
            print(dataset.name)

    def import_analysis(self, destination, name, description, details, filepath, params, inputs, outputs):

        src = filepath
        dst = destination
        if(src.endswith('/')):
            src = src[:-1]
        if(not dst.endswith('/')):
            dst = dst + '/'

        filename = os.path.basename(src)
        dst = dst + filename
        shutil.copy(src, dst)
        created = datetime.now()
        user = getpass.getuser()

        am = Analysis(name=name, filepath=filepath, description=description, details=details, created=created, user=user, parameters=params, inputs=inputs, outputs=outputs)

        self.session.add(am)
        self.session.commit()

    def run_analysis(self, modulename, params, inputs, features=None):

        am = self.session.query(Analysis).from_statement(text("SELECT * FROM analysis where name=:name")).\
            params(name=modulename).first()
        inputs = inputs.split('-')
        filepaths = ''
        filepathsarr = []

        for inputfile in inputs:
            ds = self.session.query(Dataset).from_statement(text("SELECT * FROM datasets where name=:name")).\
                params(name=inputfile).first()
            filepathsarr.append(ds.filepath)

        filepaths = ','.join(filepathsarr)
        if(features is None):
            call(["/opt/spark/bin/pyspark", am.filepath, "--master", self.config['CLUSTER_URL'], params, filepaths])
        else:
            call(["/opt/spark/bin/pyspark", am.filepath, "--master", self.config['CLUSTER_URL'], params, filepaths, features])

    def import_dataset(self, inputs, description, details, userdatadir):

        # am = self.session.query(Analysis).from_statement(text("SELECT * FROM analysis where name=:name")).\
        #    params(name="dataimport").first()
        path = dirname(dirname(os.path.abspath(__file__)))
        call(["/opt/spark/bin/pyspark", path + "/data_import.py", "--master", self.config['CLUSTER_URL'], inputs, description, details, userdatadir])

    def create_dataset(self, params):

        d = self.session.query(Dataset).from_statement(text("SELECT * FROM datasets where name=:name")).\
            params(name=params['name']).first()

        if(d is None):

            ds = Dataset(name=params['name'], description=params['description'], details=params['details'], module_parameters='', created=params['created'], user=params['user'], fileformat="Parquet", filepath=params['filepath'], schema=params['schema'], module_id='')
            self.session.add(ds)
            self.session.commit()

            options = {'os_auth_url': self.config['SWIFT_AUTH_URL'], 'os_username': self.config['SWIFT_USERNAME'], 'os_password': self.config['SWIFT_PASSWORD'], 'os_tenant_id': self.config['SWIFT_TENANT_ID'], 'os_tenant_name': self.config['SWIFT_TENANT_NAME']}
            swService = SwiftService(options=options)
            obs = []
            obs.append(SwiftUploadObject(self.config['DB_LOCATION'], object_name='metadata'))

            sfUpload = swService.upload(container='containerFiles', objects=obs)
            for su in sfUpload:
                print("Metadata changed and uploaded")

        else:
            raise ValueError("The dataset with name " + params['name'] + " already exists")

    def create_relation(self, featset, parents):

        fs = self.session.query(Dataset).from_statement(text("SELECT * FROM datasets where name=:name")).\
            params(name=featset).first()
        parents = parents.split(',')
        for p in parents:
            dss = self.session.query(Dataset).from_statement(text("SELECT * FROM datasets where name=:name")).\
                params(name=p).first()

            f = fs_to_ds.insert().values(left_fs_id=fs.id, right_ds_id=dss.id)
            self.session.execute(f)

        self.session.commit()

    def create_featureset(self, params):

        modulename = params['modulename']
        am = self.session.query(Analysis).from_statement(text("SELECT * FROM analysis where name=:name")).\
            params(name=modulename).first()

        if(am is not None):  # Check if the module exists

            module_id = am.id
            d = self.session.query(Dataset).from_statement(text("SELECT * FROM datasets where name=:name")).\
                params(name=params['name']).first()

            if(d is None):
                ds = Dataset(name=params['name'], description=params['description'], details=params['details'], module_parameters=params['module_parameters'], created=params['created'], user=params['user'], fileformat="Parquet", filepath=params['filepath'], schema=params['schema'], module_id=am.id)
                self.session.add(ds)
                self.session.commit()

                options = {'os_auth_url': self.config['SWIFT_AUTH_URL'], 'os_username': self.config['SWIFT_USERNAME'], 'os_password': self.config['SWIFT_PASSWORD'], 'os_tenant_id': self.config['SWIFT_TENANT_ID'], 'os_tenant_name': self.config['SWIFT_TENANT_NAME']}
                sfService = SwiftService(options=options)
                obs = []
                obs.append(SwiftUploadObject(self.config['DB_LOCATION'], object_name='metadata'))
                sfUpload = swService.upload(container='containerFiles', objects=obs)
                for su in sfUpload:
                    print("Metadata changed and uploaded")
            else:
                raise ValueError('The feature set with the name ' + params['name'] + ' already exists')
        else:
            raise ValueError('No Such Module')
