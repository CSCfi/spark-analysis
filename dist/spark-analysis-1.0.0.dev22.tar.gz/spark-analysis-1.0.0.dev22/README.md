[![Build Status](https://travis-ci.org/CSC-IT-Center-for-Science/spark-analysis.svg?branch=master)](https://travis-ci.org/CSC-IT-Center-for-Science/spark-analysis)

# Spark Analysis
Analyzing large datasets using spark 

# Run dev scripts like
python -m bin.sparkles --config-file <e.g. etc/config.yml> [run, list, ...]

